// Friendly labels. Anything missing falls back to the raw column name.
export const FIELD_LABELS = {
  Experience_Years: "Experience (years)",
  Industry_Experience_Years: "Industry experience (years)",
  Years_in_Current_Role: "Years in current role",
  Years_at_Company: "Years at company",
  Certifications_Count: "Certifications",
  Technical_Skills_Count: "Technical skills",
  Team_Size_Managed: "Team size managed",
  Employee_Count: "Company headcount",
  Working_Hours_Per_Week: "Working hours / week",
  Performance_Rating: "Performance rating (0–5)",
  Job_Grade: "Job grade",
  Job_Evaluation_Score: "Job evaluation score",
  Local_Median_Salary: "Local median salary (PKR)",
  Inflation_Rate: "Inflation rate (%)",
  Management_Responsibility: "Management responsibility",
};

export const fieldLabel = (col) =>
  FIELD_LABELS[col] ?? col.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());

// Fields the backend expects as whole numbers
export const INTEGER_FIELDS = new Set([
  "Certifications_Count", "Technical_Skills_Count", "Team_Size_Managed",
  "Employee_Count", "Working_Hours_Per_Week", "Year",
]);

// Required by the API; everything else is optional and imputed when missing.
export const CORE_FIELDS = ["Job_Title", "Job_Level", "Experience_Years", "Education_Level", "City"];

export const pkr = (n) => `PKR ${Math.round(n).toLocaleString("en-US")}`;

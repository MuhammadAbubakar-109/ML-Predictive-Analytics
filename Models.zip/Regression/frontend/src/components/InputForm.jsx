import { useRef, useState } from "react";
import { CORE_FIELDS, INTEGER_FIELDS, fieldLabel } from "../labels";

// Quick-fill profiles. Values not in the dataset's options are skipped automatically.
const PRESETS = {
  entry: {
    label: "Entry-level example",
    values: {
      Job_Title: "Receptionist", Job_Level: "Junior", Experience_Years: 1,
      Education_Level: "Intermediate", City: "Multan",
      Management_Responsibility: "No", Team_Size_Managed: 0,
    },
  },
  senior: {
    label: "Senior example",
    values: {
      Job_Title: "Software Engineer", Job_Level: "Director", Experience_Years: 18,
      Education_Level: "Master's", City: "Karachi", Company_Type: "Multinational",
      Management_Responsibility: "Yes", Team_Size_Managed: 40,
    },
  },
};

function initialValues(options, models) {
  const values = { model: models.best_model, ...options.defaults_categorical };
  for (const [k, v] of Object.entries(options.numeric)) {
    values[k] = INTEGER_FIELDS.has(k) ? Math.round(v.median) : v.median;
  }
  return values;
}

export default function InputForm({ options, models, onSubmit, onCompareAll, loading }) {
  const { categorical, numeric } = options;
  const [values, setValues] = useState(() => initialValues(options, models));
  const [showMore, setShowMore] = useState(false);
  const formRef = useRef(null);

  const set = (k, v) => setValues((p) => ({ ...p, [k]: v }));

  function buildPayload() {
    const payload = {};
    for (const [k, v] of Object.entries(values)) {
      if (v === "" || v === null || v === undefined) continue;
      payload[k] = numeric[k] ? (INTEGER_FIELDS.has(k) ? Math.round(Number(v)) : Number(v)) : v;
    }
    return payload;
  }

  function applyPreset(preset) {
    setValues((prev) => {
      const next = { ...prev };
      for (const [k, v] of Object.entries(preset.values)) {
        if (numeric[k]) next[k] = Math.min(Math.max(v, numeric[k].min), numeric[k].max);
        else if (categorical[k]?.includes(v)) next[k] = v;
      }
      return next;
    });
  }

  function handleCompare() {
    if (formRef.current?.reportValidity()) onCompareAll(buildPayload());
  }

  const field = (k) =>
    categorical[k] ? (
      <div className="field" key={k}>
        <label htmlFor={k}>{fieldLabel(k)}</label>
        <select id={k} value={values[k] ?? ""} onChange={(e) => set(k, e.target.value)}>
          {categorical[k].map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
      </div>
    ) : (
      <div className="field" key={k}>
        <label htmlFor={k}>{fieldLabel(k)}</label>
        <input
          id={k} type="number" step="any" required={CORE_FIELDS.includes(k)}
          min={numeric[k].min} max={numeric[k].max}
          value={values[k] ?? ""}
          onChange={(e) => set(k, e.target.value === "" ? "" : Number(e.target.value))}
        />
        <small className="muted">{k === "Year" ? `${numeric[k].min} – ${numeric[k].max}` : `${numeric[k].min.toLocaleString()} – ${numeric[k].max.toLocaleString()}`}</small>
      </div>
    );

  const more = [...Object.keys(categorical), ...Object.keys(numeric)].filter(
    (k) => !CORE_FIELDS.includes(k)
  );

  return (
    <form
      className="card" ref={formRef}
      onSubmit={(e) => { e.preventDefault(); onSubmit(buildPayload()); }}
    >
      <h2>Employee details</h2>

      <div className="presets">
        <span className="muted">Quick fill:</span>
        {Object.entries(PRESETS).map(([key, p]) => (
          <button type="button" key={key} className="secondary" onClick={() => applyPreset(p)}>
            {p.label}
          </button>
        ))}
      </div>

      <div className="field model-field">
        <label htmlFor="model">Model</label>
        <select id="model" value={values.model} onChange={(e) => set("model", e.target.value)}>
          {models.models.map((m) => (
            <option key={m.id} value={m.id}>{m.name}{m.is_best ? " (best)" : ""}</option>
          ))}
        </select>
      </div>

      <h3>Core</h3>
      <div className="grid">{CORE_FIELDS.map(field)}</div>

      <button type="button" className="link" onClick={() => setShowMore(!showMore)}>
        {showMore ? "Hide" : "Show"} more details ({more.length} optional fields)
      </button>
      {showMore && <div className="grid more">{more.map(field)}</div>}

      <div className="actions">
        <button type="submit" disabled={loading}>{loading ? "Predicting…" : "Predict salary"}</button>
        <button type="button" className="secondary" disabled={loading} onClick={handleCompare}>
          Compare all models
        </button>
      </div>
    </form>
  );
}

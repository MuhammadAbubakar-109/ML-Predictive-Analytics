// [key, title, better] — "min" means lower is better
const COLUMNS = [
  ["cv_rmse", "CV RMSE", "min"],
  ["r2", "R²", "max"],
  ["mae", "MAE", "min"],
  ["rmse", "RMSE", "min"],
  ["mape", "MAPE %", "min"],
];

const fmt = (key, v) =>
  v == null ? "–" : key === "r2" ? v.toFixed(3) : key === "mape" ? v.toFixed(1) : Math.round(v).toLocaleString("en-US");

export default function ModelComparison({ info, models }) {
  if (!info?.comparison?.length) return null;
  const name = (id) => models.models.find((m) => m.id === id)?.name ?? id;

  const best = {};
  for (const [key, , dir] of COLUMNS) {
    const vals = info.comparison.map((r) => r[key]).filter((v) => v != null);
    best[key] = dir === "min" ? Math.min(...vals) : Math.max(...vals);
  }

  return (
    <section className="card comparison">
      <h2>Model comparison</h2>
      <p className="muted">
        Test-set metrics in PKR, sorted by cross-validated RMSE. Best value per column is highlighted.
        Trained {new Date(info.trained_at).toLocaleString()} on {info.n_rows.toLocaleString()} rows.
      </p>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Model</th>{COLUMNS.map(([, t]) => <th key={t}>{t}</th>)}</tr>
          </thead>
          <tbody>
            {info.comparison.map((row) => (
              <tr key={row.model}>
                <td>{name(row.model)}{row.model === info.best_model && <span className="badge low"> best</span>}</td>
                {COLUMNS.map(([key]) => (
                  <td key={key} className={row[key] === best[key] ? "top" : ""}>{fmt(key, row[key])}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

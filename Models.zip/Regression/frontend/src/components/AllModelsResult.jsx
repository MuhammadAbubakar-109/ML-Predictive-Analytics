import { pkr } from "../labels";

export default function AllModelsResult({ results, models }) {
  if (!results) return null;

  const name = (id) => models.models.find((m) => m.id === id)?.name ?? id;
  const vals = results.map((r) => r.monthly_salary_pkr);
  const lo = Math.min(...vals);
  const hi = Math.max(...vals);
  const mid = [...vals].sort((a, b) => a - b)[Math.floor(vals.length / 2)];
  const spread = mid > 0 ? (hi - lo) / mid : 0;

  return (
    <aside className="card">
      <h2>All models, same input</h2>
      <table className="compact">
        <thead>
          <tr><th>Model</th><th>Monthly (PKR)</th></tr>
        </thead>
        <tbody>
          {results.map((r) => (
            <tr key={r.model}>
              <td>{name(r.model)}{r.model === models.best_model && <span className="badge low"> best</span>}</td>
              <td>{Math.round(r.monthly_salary_pkr).toLocaleString("en-US")}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="muted note">
        Lowest {pkr(lo)}, highest {pkr(hi)}.
        {spread > 0.5 && " The models disagree a lot on this input; treat the estimate with caution."}
      </p>
    </aside>
  );
}

import { pkr } from "../labels";

export default function PredictionResult({ result, models, loading }) {
  if (loading) {
    return <aside className="card"><p className="muted">Running model…</p></aside>;
  }
  if (!result) {
    return (
      <aside className="card">
        <h2>Result</h2>
        <p className="muted">Fill in the form and press Predict salary.</p>
      </aside>
    );
  }
  const name = models.models.find((m) => m.id === result.model)?.name ?? result.model;

  return (
    <aside className="card">
      <h2>Result</h2>
      <p className="muted">Estimated monthly salary</p>
      <p className="amount">{pkr(result.monthly_salary_pkr)}</p>
      <p className="muted">≈ {pkr(result.annual_salary_pkr)} per year</p>
      <dl>
        <dt>Typical range (PKR)</dt>
        <dd>{Math.round(result.range_low_pkr).toLocaleString("en-US")} – {Math.round(result.range_high_pkr).toLocaleString("en-US")}</dd>
        <dt>Model</dt>
        <dd>{name}</dd>
      </dl>
      <p className="muted note">Range = prediction ± the model's average error on held-out test data.</p>
    </aside>
  );
}

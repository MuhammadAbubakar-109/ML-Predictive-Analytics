import { useEffect, useState } from "react";
import AllModelsResult from "./components/AllModelsResult.jsx";
import InputForm from "./components/InputForm.jsx";
import ModelComparison from "./components/ModelComparison.jsx";
import PredictionResult from "./components/PredictionResult.jsx";
import { getModelInfo, getModels, getOptions, predictAll, predictSalary } from "./services/api.js";

export default function App() {
  const [models, setModels] = useState(null);
  const [options, setOptions] = useState(null);
  const [info, setInfo] = useState(null);
  const [result, setResult] = useState(null);
  const [allResults, setAllResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([getModels(), getOptions(), getModelInfo()])
      .then(([m, o, i]) => { setModels(m); setOptions(o); setInfo(i); })
      .catch((e) => setError(e.message));
  }, []);

  async function run(fn, onDone) {
    setLoading(true);
    setError("");
    try { onDone(await fn()); }
    catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }

  const handleSubmit = (payload) => {
    setResult(null);
    return run(() => predictSalary(payload), setResult);
  };
  const handleCompareAll = (payload) => {
    setAllResults(null);
    return run(() => predictAll(payload), (d) => setAllResults(d.results));
  };

  return (
    <main className="container">
      <header>
        <h1>Employee Salary Predictor</h1>
        <p className="muted">Estimate monthly salary (PKR) from job, experience and company details.</p>
      </header>

      {error && <div className="alert">{error}</div>}

      {options && models && (
        <>
          <div className="layout">
            <InputForm
              options={options} models={models} loading={loading}
              onSubmit={handleSubmit} onCompareAll={handleCompareAll}
            />
            <div className="side">
              <PredictionResult result={result} models={models} loading={loading} />
              <AllModelsResult results={allResults} models={models} />
            </div>
          </div>
          <ModelComparison info={info} models={models} />
        </>
      )}
      {!options && !error && <p className="muted">Loading…</p>}
    </main>
  );
}

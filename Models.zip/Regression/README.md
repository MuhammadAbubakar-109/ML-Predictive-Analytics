# Employee Salary Prediction (Regression)

Full-stack ML project: predicts **monthly salary (PKR)** from job, experience and company details.
Six regressors are trained, tuned, compared and **all saved**. The FastAPI backend serves any of them
(or all at once), and the React UI lets you pick a model, compare them, and see the metrics.

## Models compared
Linear Regression · Ridge · Lasso · Decision Tree · Random Forest · SVR
(each tuned with `GridSearchCV`; salary is modelled on a log scale because it is right-skewed)

## Results (20% hold-out test set)
| Model | R² | MAE (PKR) | RMSE (PKR) |
|---|---|---|---|
| **Ridge (best, lowest CV-RMSE)** | 0.931 | 14,284 | 23,893 |
| Linear Regression | 0.931 | 14,284 | 23,905 |
| Lasso | 0.932 | 14,332 | 23,728 |
| SVR | 0.906 | 14,791 | 28,001 |
| Random Forest | 0.854 | 21,182 | 34,795 |
| Decision Tree | 0.752 | 28,069 | 45,363 |

Regenerated in `models/metadata.json` and `models/comparison.csv` on every training run.

## Quick start (PowerShell)
```powershell
pip install -r requirements.txt
python -m src.ml.train             # trains all 6, saves models/<name>.joblib + model.joblib + metadata.json
python -m pytest -q                # 12 tests
uvicorn src.api.main:app --reload --port 8000     # http://localhost:8000/docs

cd frontend
npm install
npm run dev                        # http://localhost:5173
```
Trained models are already included in `models/`, so you can skip the training step.
Or with Docker: `docker compose up --build`.

## API
| Endpoint | Purpose |
|---|---|
| `GET /health` | liveness + list of loaded model artifacts |
| `GET /models` | available models, marks the best one |
| `GET /options` | dropdown values and numeric ranges (the UI form is built from this) |
| `GET /model-info` | best model, trained-at, full comparison metrics |
| `POST /predict` | one prediction; optional `"model": "<id>"` (default: best). Returns salary, annual, and typical range (± test MAE) |
| `POST /predict-all` | same input scored by every saved model |

Required fields: `Job_Title, Job_Level, Experience_Years, Education_Level, City`. Everything else is optional and imputed.

## Frontend features
Model selector · quick-fill presets · core vs optional fields · "Compare all models" panel ·
model-comparison table (best per column highlighted) · friendly labels · light/dark theme · API error banner.

## Structure
```
src/ml/     data · features · train · evaluate · predict     (all ML logic)
src/api/    main · schemas · config                          (thin serving layer)
frontend/   React + Vite UI (form built from GET /options)
configs/    config.yaml: features, models, grids, artifact paths
models/     <model>.joblib x6, model.joblib (best), metadata.json, comparison.csv
tests/      API + ML tests
```

## Adding a model
Add an entry under `models:` in `configs/config.yaml` **and** a path under `paths.models`, then retrain.
Optionally add a display name in `src/ml/predict.py` (`DISPLAY`).

## Known limitation
SVR compresses extreme salaries (very junior or very senior profiles drift toward the middle). The
"Compare all models" panel makes this visible; prefer Ridge/Lasso for the tails.

"""Train all regressors, compare them, and save every fitted model.

Run:  python -m src.ml.train            (or: make train)
"""
import importlib
import json
import time
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import TransformedTargetRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline

from src.ml.data import ROOT, feature_columns, load_config, load_data, split
from src.ml.evaluate import regression_metrics
from src.ml.features import build_preprocessor


def _import(path: str):
    module, cls = path.rsplit(".", 1)
    return getattr(importlib.import_module(module), cls)


def build_estimator(spec: dict, cfg: dict):
    model = _import(spec["class"])(**spec.get("fixed", {}))
    pipe = Pipeline([("prep", build_preprocessor(cfg)), ("model", model)])
    if cfg["training"]["log_target"]:
        pipe = TransformedTargetRegressor(regressor=pipe, func=np.log1p, inverse_func=np.expm1)
        prefix = "regressor__model__"
    else:
        prefix = "model__"
    grid = {prefix + k: v for k, v in spec.get("params", {}).items()}
    return pipe, grid


def main() -> None:
    cfg = load_config()
    paths = cfg["paths"]
    individual = paths.get("models", {})

    missing = set(cfg["models"]) - set(individual)
    if missing:
        raise ValueError(f"Add paths.models entries in the config for: {sorted(missing)}")

    df = load_data(cfg)
    X_train, X_test, y_train, y_test = split(df, cfg)
    print(f"Rows: {len(df)} | train: {len(X_train)} | test: {len(X_test)}")

    (ROOT / "models").mkdir(exist_ok=True)
    results, fitted = [], {}

    for name, spec in cfg["models"].items():
        est, grid = build_estimator(spec, cfg)
        search = GridSearchCV(
            est, grid, cv=cfg["training"]["cv_folds"],
            scoring="neg_root_mean_squared_error", n_jobs=-1,
        )
        t0 = time.time()
        search.fit(X_train, y_train)
        m = regression_metrics(y_test, search.predict(X_test))
        row = {
            "model": name,
            "cv_rmse": float(-search.best_score_),
            "best_params": {k.split("__")[-1]: v for k, v in search.best_params_.items()},
            "seconds": round(time.time() - t0, 1),
            **{f"test_{k}": v for k, v in m.items()},
        }
        results.append(row)
        fitted[name] = search.best_estimator_

        # Save immediately so a crash on a later model never loses earlier ones.
        art = ROOT / individual[name]
        art.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(search.best_estimator_, art, compress=3)

        print(f"{name:18s} CV-RMSE {row['cv_rmse']:>10,.0f} | test R2 {m['r2']:.4f} "
              f"| MAE {m['mae']:>9,.0f} | {row['seconds']}s | saved -> {individual[name]}")

    best = min(results, key=lambda r: r["cv_rmse"])
    print(f"\nBest model: {best['model']}")

    # Options for the UI / API (categories + numeric ranges seen in training data)
    options = {
        "categorical": {c: sorted(df[c].dropna().unique().tolist())
                        for c in cfg["features"]["categorical"]},
        "numeric": {c: {"min": float(df[c].min()), "max": float(df[c].max()),
                        "median": float(df[c].median())}
                    for c in cfg["features"]["numeric"]},
        "defaults_categorical": {c: df[c].mode().iloc[0] for c in cfg["features"]["categorical"]},
    }

    joblib.dump(fitted[best["model"]], ROOT / paths["model"], compress=3)
    metadata = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "best_model": best["model"],
        "target": cfg["data"]["target"],
        "features": feature_columns(cfg),
        "n_rows": len(df),
        "target_mean": float(df[cfg["data"]["target"]].mean()),
        "comparison": sorted(results, key=lambda r: r["cv_rmse"]),
        "options": options,
    }
    with open(ROOT / paths["metadata"], "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, default=str)
    pd.DataFrame(results).drop(columns="best_params").to_csv(
        ROOT / "models" / "comparison.csv", index=False)
    print(f"Saved {len(fitted)} models + {paths['model']}, {paths['metadata']}")


if __name__ == "__main__":
    main()

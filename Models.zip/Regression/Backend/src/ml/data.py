"""Load config + data, validate schema, split."""
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[2]


def load_config(path: str | Path = ROOT / "configs" / "config.yaml") -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def feature_columns(cfg: dict) -> list[str]:
    return cfg["features"]["numeric"] + cfg["features"]["categorical"]


def load_data(cfg: dict) -> pd.DataFrame:
    df = pd.read_csv(ROOT / cfg["data"]["path"])
    return validate(df, cfg)


def validate(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """Fail fast on schema problems; drop unusable rows."""
    required = feature_columns(cfg) + [cfg["data"]["target"]]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    target = cfg["data"]["target"]
    df = df.drop_duplicates().dropna(subset=[target])
    df = df[df[target] > 0]
    return df.reset_index(drop=True)


def split(df: pd.DataFrame, cfg: dict):
    X = df[feature_columns(cfg)].copy()
    # object dtype + np.nan keeps sklearn imputers happy across pandas versions
    for c in cfg["features"]["categorical"]:
        X[c] = X[c].astype(object).where(X[c].notna(), np.nan)
    y = df[cfg["data"]["target"]]
    s = cfg["split"]
    return train_test_split(X, y, test_size=s["test_size"], random_state=s["random_state"])

"""Load saved models and predict. The only ML entry point the API uses."""
import json
from functools import lru_cache

import joblib
import numpy as np
import pandas as pd

from src.ml.data import ROOT, load_config

DISPLAY = {
    "linear_regression": "Linear Regression",
    "ridge": "Ridge",
    "lasso": "Lasso",
    "decision_tree": "Decision Tree",
    "random_forest": "Random Forest",
    "svr": "SVR",
}


def pretty(name: str) -> str:
    return DISPLAY.get(name, name.replace("_", " ").title())


@lru_cache(maxsize=1)
def _cfg() -> dict:
    return load_config()


def get_metadata() -> dict:
    path = ROOT / _cfg()["paths"]["metadata"]
    if not path.exists():
        raise FileNotFoundError("metadata.json not found. Run: python -m src.ml.train")
    return json.loads(path.read_text(encoding="utf-8"))


def available_models() -> list[str]:
    """Configured models whose saved artifact exists on disk."""
    return [n for n, p in _cfg()["paths"].get("models", {}).items() if (ROOT / p).exists()]


@lru_cache(maxsize=8)
def load_model(name: str):
    paths = _cfg()["paths"].get("models", {})
    if name not in paths or not (ROOT / paths[name]).exists():
        raise KeyError(name)
    return joblib.load(ROOT / paths[name])


def _frame(record: dict) -> pd.DataFrame:
    cfg = _cfg()
    df = pd.DataFrame([{c: record.get(c) for c in get_metadata()["features"]}])
    for c in cfg["features"]["numeric"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    for c in cfg["features"]["categorical"]:
        df[c] = df[c].astype(object).where(df[c].notna(), np.nan)
    return df


def typical_error(name: str) -> float:
    """Test-set MAE of a model, used as the +/- band around a prediction."""
    for row in get_metadata()["comparison"]:
        if row["model"] == name:
            return float(row["test_mae"])
    return 0.0


def predict(record: dict, model_name: str | None = None) -> dict:
    """Predict monthly salary (PKR) with one model (default: the best one)."""
    name = model_name or get_metadata()["best_model"]
    monthly = max(float(load_model(name).predict(_frame(record))[0]), 0.0)
    mae = typical_error(name)
    return {
        "model": name,
        "monthly_salary_pkr": round(monthly),
        "annual_salary_pkr": round(monthly * 12),
        "range_low_pkr": round(max(monthly - mae, 0)),
        "range_high_pkr": round(monthly + mae),
    }


def predict_all(record: dict) -> list[dict]:
    """Score one input with every saved model."""
    frame = _frame(record)
    out = []
    for name in available_models():
        monthly = max(float(load_model(name).predict(frame)[0]), 0.0)
        out.append({"model": name, "monthly_salary_pkr": round(monthly),
                    "annual_salary_pkr": round(monthly * 12)})
    return out

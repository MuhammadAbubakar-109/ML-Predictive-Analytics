"""Thin serving layer: all ML logic lives in src/ml."""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from src.api.config import settings
from src.api.schemas import PredictAllResponse, PredictRequest, PredictResponse
from src.ml import predict as engine

app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=settings.cors_origins,
    allow_methods=["*"], allow_headers=["*"],
)

NOT_TRAINED = "Model not trained yet. Run `python -m src.ml.train`."


def _meta() -> dict:
    try:
        return engine.get_metadata()
    except FileNotFoundError:
        raise HTTPException(503, NOT_TRAINED)


@app.get("/health")
def health():
    _meta()
    return {"status": "ok", "models_loaded": engine.available_models()}


@app.get("/model-info")
def model_info():
    meta = _meta()
    best = meta["comparison"][0]
    return {
        "best_model": meta["best_model"],
        "trained_at": meta["trained_at"],
        "n_rows": meta["n_rows"],
        "target": meta["target"],
        "metrics": {k: best[f"test_{k}"] for k in ("rmse", "mae", "r2", "mape")},
        "comparison": [
            {"model": r["model"], "cv_rmse": r["cv_rmse"], "r2": r["test_r2"],
             "mae": r["test_mae"], "rmse": r["test_rmse"], "mape": r["test_mape"],
             "seconds": r["seconds"]}
            for r in meta["comparison"]
        ],
    }


@app.get("/models")
def list_models():
    best = _meta()["best_model"]
    return {
        "best_model": best,
        "models": [{"id": n, "name": engine.pretty(n), "is_best": n == best}
                   for n in engine.available_models()],
    }


@app.get("/options")
def options():
    """Dropdown values + numeric ranges so the UI builds its form dynamically."""
    return _meta()["options"]


def _check_model(name: str | None) -> None:
    if name and name not in engine.available_models():
        raise HTTPException(400, f"Unknown model '{name}'. Available: {engine.available_models()}")


@app.post("/predict", response_model=PredictResponse)
def predict_salary(req: PredictRequest):
    _meta()
    _check_model(req.model)
    record = req.model_dump(exclude={"model"})
    return engine.predict(record, req.model)


@app.post("/predict-all", response_model=PredictAllResponse)
def predict_all(req: PredictRequest):
    _meta()
    return {"results": engine.predict_all(req.model_dump(exclude={"model"}))}
